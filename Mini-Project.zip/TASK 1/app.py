import streamlit as st
import pandas as pd
import pickle
from datetime import datetime

# -----------------------------------------------------
# PAGE CONFIG
# -----------------------------------------------------
st.set_page_config(
    page_title="Smart Energy Predictor",
    page_icon="⚡",
    layout="centered",
)

# -----------------------------------------------------
# GLOBAL CSS FIX (removes blue bar)
# -----------------------------------------------------
st.markdown("""
    <style>
        /* Removes Streamlits default empty container spacing */
        .block-container {
            padding-top: 1rem;
        }

        /* Completely remove top margin from markdown elements */
        h1, h3, p, div {
            margin-top: 0 !important;
        }

        /* Remove strange horizontal bar created by markdown */
        .stMarkdown {
            margin: 0 !important;
            padding: 0 !important;
        }

        .input-card {
            background: #e8f4fa;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
            margin-top: 10px;
            margin-bottom: 20px;
        }

        .predict-btn button {
            background-color: #4CAF50 !important;
            color: white !important;
            padding: 10px 20px !important;
            border-radius: 8px !important;
            font-size: 18px !important;
        }

        .result-box {
            background: #e9ffe9;
            padding: 22px;
            border-radius: 12px;
            border-left: 6px solid #2ecc71;
            margin-top: 20px;
        }

        h1 {
            color: #1B4F72;
            text-align: center;
            font-weight: 900;
        }

        h3 {
            color: #1A5276;
        }
    </style>
""", unsafe_allow_html=True)

# -----------------------------------------------------
# LOAD MODEL
# -----------------------------------------------------
with open("energy_model.pkl", "rb") as f:
    model = pickle.load(f)

# -----------------------------------------------------
# HEADER (No spacing, no extra bar)
# -----------------------------------------------------
st.markdown("<h1>⚡ Smart Home Energy Consumption Predictor</h1>", unsafe_allow_html=True)
st.write("Enter details below to predict hourly energy usage.")

# -----------------------------------------------------
# INPUT CARD (NOW ONLY HERE, NO BLUE BOX ABOVE)
# -----------------------------------------------------
# st.markdown("<div class='input-card'>", unsafe_allow_html=True)
st.markdown("### 🔧 Input Features")

col1, col2 = st.columns(2)

with col1:
    year = st.number_input("📅 Year", 2000, 2100, 2033)
    month = st.number_input("🗓 Month", 1, 12, 7)

with col2:
    day = st.number_input("📆 Day", 1, 31, 16)
    hour = st.number_input("⏰ Hour (0-23)", 0, 23, 13)

st.markdown("</div>", unsafe_allow_html=True)

# -----------------------------------------------------
# FEATURE ENGINEERING
# -----------------------------------------------------
dt = datetime(year, month, day, hour)
dayofweek = dt.weekday()
is_weekend = 1 if dayofweek >= 5 else 0

# Dummy placeholders
lag_1 = lag_24 = lag_168 = 0
roll_24 = roll_168 = 0

input_data = pd.DataFrame({
    'hour': [hour],
    'dayofweek': [dayofweek],
    'month': [month],
    'year': [year],
    'lag_1': [lag_1],
    'lag_24': [lag_24],
    'lag_168': [lag_168],
    'roll_24': [roll_24],
    'roll_168': [roll_168],
    'is_weekend': [is_weekend],
})

# -----------------------------------------------------
# PREDICT BUTTON
# -----------------------------------------------------
st.markdown("<div class='predict-btn'>", unsafe_allow_html=True)

if st.button("🔮 Predict Energy Consumption"):
    prediction = model.predict(input_data)[0]

    st.markdown(
        f"""
        <div class='result-box'>
            <h3>⚡ Predicted Consumption:</h3>
            <h2 style="color:#1e8449;">{prediction:.2f} MW</h2>
        </div>
        """,
        unsafe_allow_html=True
    )
